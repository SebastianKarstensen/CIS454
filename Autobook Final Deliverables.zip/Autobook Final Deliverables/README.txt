Install from APK:

1. Transfer Autobook.apk file to your Android phone.

2. On your phone, open your file manager and navigate to the directory where you transferred the .apk file.

3. Tap the file and install. 

4. You are done!


Install from Android Studio:

1. Download Android Studio.

2. Open the project in Android Studio.

3. Run the project from HomeActivity.

