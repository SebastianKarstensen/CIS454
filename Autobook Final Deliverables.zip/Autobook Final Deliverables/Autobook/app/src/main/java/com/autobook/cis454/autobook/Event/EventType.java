package com.autobook.cis454.autobook.Event;

/**
 * EventType to be used with Event
 */
public enum EventType
{
    //If changes are made, please remember to update the convertStringToEnum()-method in CalendarActivity
    American_Holiday, Anniversary, Birthday, Party, Wedding, Other
}
