package com.autobook.cis454.autobook.Event;

/**
 * MediaType to be used with Event when clicked on the home screen.
 */
public enum MediaType {
    Facebook, Twitter, TextMessaging, Null
}
